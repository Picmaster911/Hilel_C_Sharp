﻿document.addEventListener("DOMContentLoaded", function () {
    var element = document.createElement("p");
    element.textContent = "Yhis contebt from scrypt";
    document.querySelector("body").appendChild(element);
});